﻿<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
//Параметры подключения
$user = "SYSDBA"; 
$pass = "masterkey";
$host = "localhost:C:\BASE.fdb";
$dbh = ibase_connect($host, $user, $pass);
//Создание БД
//ibase_query(IBASE_CREATE, "CREATE DATABASE '$host' USER '$user' PASSWORD '$pass'");

//ibase_close();
echo 'База данных успешно создана!</br>';
echo 'Структура базы данных:</br>';
$dbh = ibase_connect($host, $user, $pass);
//Начало транзакции
ibase_trans();
//Создание таблиц																		
ibase_query($dbh, "CREATE TABLE Users (id INTEGER primary key, name VARCHAR(50) not null, date_born DATE, adress VARCHAR(100) not null, phone SMALLINT)") or die ("Сбой при доступе к БД: " . ibase_errcode());
ibase_query($dbh, "CREATE TABLE Purchase (id INTEGER primary key, name VARCHAR(50) not null, cost INTEGER, userid INTEGER REFERENCES Users not null  , date_purchase TIMESTAMP)") or die ("Сбой при доступе к БД: " . ibase_errmsg());

$tablename = 'Users';
$primarykey = 'ID';

ibase_query($dbh, 'CREATE GENERATOR GEN_' . $tablename . '_PK;');
ibase_query($dbh, 'CREATE TRIGGER INC_' . $primarykey . ' FOR ' . $tablename
. chr(13) . 'ACTIVE BEFORE INSERT POSITION 0'
. chr(13) . 'AS'
. chr(13) . 'BEGIN'
. chr(13) . 'IF (NEW.' . $primarykey . ' IS NULL) THEN'
. chr(13) . 'NEW.' . $primarykey . '= GEN_ID(GEN_' . $tablename . '_PK, 1);'
. chr(13) . 'END');

$tablename = 'Purchase';
$primarykey = 'ID';
 ibase_query($dbh, 'CREATE GENERATOR GEN_' . $tablename . '_PK;');
 ibase_query($dbh, 'CREATE TRIGGER INC_2' . $primarykey . ' FOR ' . $tablename
 . chr(13) . 'ACTIVE BEFORE INSERT POSITION 0'
 . chr(13) . 'AS'
 . chr(13) . 'BEGIN'
 . chr(13) . 'IF (NEW.' . $primarykey . ' IS NULL) THEN'
 . chr(13) . 'NEW.' . $primarykey . '= GEN_ID(GEN_' . $tablename . '_PK, 1);'
 . chr(13) . 'END');

ibase_commit();
//Вывод информации о таблицах
getTableInfo($host, $user, $pass);
ibase_trans();
echo '</br>Измененная структура базы данных:</br>';
//Изменение структуры таблицы
$dbh = ibase_connect($host, $user, $pass);
ibase_query($dbh, "ALTER TABLE Purchase ADD description VARCHAR(50)");
ibase_query($dbh, "ALTER TABLE Users DROP phone");
ibase_query($dbh, "ALTER TABLE Users add email VARCHAR(50)");
ibase_commit();

//Вывод информации о таблицах
getTableInfo($host, $user, $pass);
$dbh = ibase_connect($host, $user, $pass);//хз
//Заполнение таблиц данными


ibase_query($dbh, "INSERT INTO Users (name,adress,date_born,email) VALUES ('Иванов','Москва','1995.12.15', 'ivanov@mail.ru')");
ibase_query($dbh, "INSERT INTO Users (name,adress,date_born,email) VALUES ('Петров','Новохопёрск','1994.10.12','petrov@mail.ru')");
ibase_query($dbh, "INSERT INTO Users (name,adress,date_born,email) VALUES ('Сидоров','Рязань','1990.06.03','sidorov@mail.ru')");

ibase_query($dbh, "INSERT INTO Purchase (name,cost,userid,date_purchase,description) VALUES ('Хлопушка','200','1','2017.11.21 12:45:45', 'были обнаружены царапины')");
ibase_query($dbh, "INSERT INTO Purchase (name,cost,userid,date_purchase,description) VALUES ('Дракон','1500','2','2017.11.15 13:45:45', 'недостатков нет')");
ibase_query($dbh, "INSERT INTO Purchase (name,cost,userid,date_purchase,description) VALUES ('Манчкин','1300','1','2017.11.02 14:45:45','недостатков нет')");
ibase_query($dbh, "INSERT INTO Purchase (name,cost,userid,date_purchase,description) VALUES ('Подарочная коробка','400','1','2017.11.06 15:45:45','недостатков нет')");
ibase_query($dbh, "INSERT INTO Purchase (name,cost,userid,date_purchase,description) VALUES ('Путевка в тайную комнату','4000','3','2017.11.23 16:25:15','недостатков нет')");


//Вывод содержимого таблиц
echo "</br>Таблица Purchase:</br><table border='1' width='80%'>
	<tr>
		<th width='10%'>ID</th>
		<th width='30%'>Название товара</th>
		<th width='15%''>Цена, руб</th>		
		<th width='20%'>Имя покупателя</th>
		<th width='20%'>Дата покупки</th>
		<th width='20%'>Отзыв</th>
	</tr>";
$result = ibase_query($dbh, "SELECT Purchase.id, Purchase.name, Purchase.cost,Users.name, Purchase.date_purchase, Purchase.description FROM Purchase,Users WHERE Purchase.userid = Users.id ") or die ("Сбой при доступе к БД: " . ibase_errmsg());
while ($row = ibase_fetch_row($result)) 
{
    echo "<tr>
		<td>$row[0]</td>
		<td>$row[1]</td>
		<td>$row[2]</td>
		<td>$row[3]</td>
		<td>$row[4]</td>
		<td>$row[5]</td></tr>";
}
echo '</table>';
echo "</br>Таблица Users:</br><table border='1' width='80%'>
	<tr>
		<th width='10%'>ID</th>
		<th width='30%'>Имя</th>
		<th width='25%''>Адрес</th>
		<th width='30%'>Дата рождения</th>
		<th width='30%'>email</th>
	</tr>";
$result = ibase_query($dbh, "SELECT * FROM Users") or die ("Сбой при доступе к БД: " . ibase_errmsg());
while ($row = ibase_fetch_row($result)) 
{
    echo "<tr>
		<td>$row[0]</td>
		<td>$row[1]</td>
		<td>$row[3]</td>		
		<td>$row[2]</td>
		<td>$row[4]</td>
		</tr>";
}
echo '</table>';

//Вывод результатов первого запроса
echo "</br>Запрос №1:</br>
Вывести информацию о покупках Иванова, сумма которых более 300</br></br>
	
	<table border='1' width='80%'>
	<tr>
		<th width='45%'>Название товара</th>
		<th width='20%''>Цена, руб</th>
		<th width='35%'>Дата покупки</th>
	</tr>";
$result = ibase_query($dbh, "SELECT name,cost,date_purchase FROM Purchase WHERE userid=(select id from Users WHERE name='Иванов') AND cost>=300") or die ("Сбой при доступе к БД: " . ibase_errmsg());
while ($row = ibase_fetch_row($result)) 
{
    echo "<tr>
		<td>$row[0]</td>
		<td>$row[1]</td>
		<td>$row[2]</td></tr>";
}
echo '</table>';

//Вывод результатов второго запроса
echo "</br>Запрос №2:</br>
Вывести информацию о покупках клиентов, определив дату последней покупки и сумму по всем заказам</br></br>

<table border='1' width='80%'>
	<tr>
		<th width='30%'>Имя</th>
		<th width='20%'>Цена</th>
		<th width='40%'>Дата покупки</th>
	</tr>";
$result = ibase_query($dbh, "SELECT U.name,P.Sum_purchase,P.Max_date FROM Users U, (SELECT userid,SUM(cost),MAX(date_purchase) FROM Purchase GROUP BY userid) AS P (userid,Sum_purchase,Max_date) WHERE P.userid=U.id") or die ("Сбой при доступе к БД: " . ibase_errmsg());
while ($row = ibase_fetch_row($result)) 
{
    echo "<tr>
		<td>$row[0]</td>
		<td>$row[1]</td>
		<td>$row[2]</td>
		</tr>";
}
echo '</table>';

echo '</br>База данных успешно удалена!</br>';
//Удаление БД
ibase_drop_db();
//$query=("DROP DATABASE");
//ibase_query($dbh, $query);
?>