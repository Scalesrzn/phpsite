<div class="container-header">
	<div class="container-header-top">
		<p class="header-text"> <br> #FACEAWARDSITALY </p>
		<a href="index.php">
			<img src="Images/logoo.jpg" alt="Логотип" class="header-logo">
		</a>	
		<p class="header-text"> <br> #FACEAWARDSITALY </p>
		<?php
		if (!empty($_SESSION['user_login']))
			echo "<div class='welcomemsg'>Добро пожаловать <b>{$_SESSION['user_login']}!!!</b> <a class='button' href='index.php?logout=true'>ВЫЙТИ</a></div>";
		?>
	</div>
</div>

