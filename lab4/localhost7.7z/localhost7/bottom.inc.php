
<p class="phone">
	Связь с нами<br>8 800 500 32 00 (РОССИЯ)  +7 495 646 91 25 (КАЗАХСТАН)
</p>

<img src="Images/pay.jpg" alt="Способ оплаты" class="pay">  
<?php date_default_timezone_set('Europe/Moscow')?>
<p class="time">
	Ваш последний визит: <?=$dateVisit?>
	<br/> Текущая дата и время: <?=date("d.m.Y H:i")?>
	<br/> Powered by <?=$_SERVER['SERVER_SOFTWARE']?>
</p>  
