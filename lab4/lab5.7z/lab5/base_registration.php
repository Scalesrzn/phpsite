<?php 
$host="localhost:C:\BASE.fdb"; 
$user="SYSDBA"; 
$pass="masterkey";
?> 