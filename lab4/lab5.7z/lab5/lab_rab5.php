<?php
$tasks = array();
$tasks[1] = array();
$tasks[1]['ask'] = 'Выполнить дублирование диска при наличии одного дисковода А: с проверкой записанных данных. (diskcopy A: /v), (diskcopy a: a:/v)';
$tasks[1]['answer_reg'] = '/^diskcopy[\s](a:[\s]a:|A:[\s])\/v$/i';
$tasks[1]['answer'] = '';

$tasks[2] = array();
$tasks[2]['ask'] = 'Удалить все файлы с расширением BAK в текущем каталоге с выдачей запроса на удаление для каждого удаляемого файла. 
(del *.bak/p), (erase *.bak/p)';
$tasks[2]['answer_reg'] = '/^(del|erase)[\s]\*\.bak\/p$/i';
$tasks[2]['answer'] = '';

$tasks[3] = array();
$tasks[3]['ask'] = 'Задать носителю данных в дисководе А: метку SYSTEM. (label a: system), (label	a:	system)';

$tasks[3]['answer_reg'] = '/^label([\s]|[\s][\s])a:([\s]|[\s][\s])system$/i';
$tasks[3]['answer'] = '';

$tasks[4] = array();
$tasks[4]['ask'] = 'Создать подкаталог TEXT в каталоге D:\EDIT. (md d:\edit\text), (mkdir d:\edit\text)';
$tasks[4]['answer_reg'] = '/^(md|mkdir)[\s]d:\\\\edit\\\\text$/i';
$tasks[4]['answer'] = '';

$tasks[5] = array();
$tasks[5]['ask'] = 'Присвоить всем файлам с расширением TXT, находящимся в каталоге C:\EDIT, новое расширение BAK. 
(ren c:\edit\*.txt *.bak), (rename c:\edit\*.txt *.bak)';
$tasks[5]['answer_reg'] = '/^(ren|rename)[\s]c:\\\\edit\\\\\*\.txt[\s]\*\.bak$/i';
$tasks[5]['answer'] = '';

function getUsersAnswers(){
	$i = 1;
	$answers[] = array();
	while(isset($_POST["answer".$i])){
		$answers[$i] = $_POST["answer".$i];
		$i++;
	}
	return $answers;
}

function getRightAnswersCount($tasks, $answers) {
	$count = 0;
	for($i = 1; $i < count($tasks)+1; $i++){
		$count += preg_match($tasks[$i]['answer_reg'], $answers[$i]) ? 1 : 0;
	}
	return $count;
}

function getMark($count) {
	if ($count == 5) return 5;
	if ($count == 4) return 4;
	if ($count == 3) return 3;
	return 2;
}

function showAsks($tasks) {
	for($i = 1; $i < count($tasks)+1; $i++) {
		echo "<b>Вопрос №$i.</b><br/>".$tasks[$i]['ask']."<br/><br/>
		Ответ: <input name='answer$i' class='answer' type='text' size='100' maxlength='255'><br/><br/>";
	}
}
?>
<form method="post">
	<?php showAsks($tasks)?>
	<input type="submit" value="Ответить" style="margin:10px">
</form>
<br/>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$answers = getUsersAnswers();
	$count = getRightAnswersCount($tasks, $answers);
	$mark = getMark($count);
	echo "<table border='1'><tr>
	<th>Правильных ответов </th>
	<td>$count</td></tr>
	<tr><th>Оценка </th>
	<td>$mark</td>
	</tr></table><br/>";
}	
?>
