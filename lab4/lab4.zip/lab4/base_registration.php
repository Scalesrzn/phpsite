<?php 
$host="localhost:D:\BASE.fdb"; 
$user="SYSDBA"; 
$pass="0";
?> 